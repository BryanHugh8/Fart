export type User={
    UserID: string,
    Commissioning: boolean,
    UserBanner: string,
    UserEmail: string,
    UserPfp: string,
    Username: string
}